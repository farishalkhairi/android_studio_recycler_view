package com.example.recycler_peler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> fotoMakanan = new ArrayList<>();
    private ArrayList<String> namaMakanan = new ArrayList<>();
    private ArrayList<String> infoMakanan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(fotoMakanan, namaMakanan, infoMakanan, this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



    }
    private  void getDataFromInternet(){

        namaMakanan.add("Ario Manggala");
        fotoMakanan.add("https://cyberthreat.id/gbr_artikel/hacker-with-laptop_23-2147985341_11.jpg");
        infoMakanan.add("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.");

        namaMakanan.add("Sardede");
        fotoMakanan.add("https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTwPAd4JzZlXereUmNCskQKjyVLy4eBhnAyWZmiy55nNatXXecA&usqp=CAU");
        infoMakanan.add("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.");

        namaMakanan.add("Yoga");
        fotoMakanan.add("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AADyvB8.img?h=315&w=600&m=6&q=60&o=t&l=f&f=jpg&x=246&y=140");
        infoMakanan.add("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.");


        namaMakanan.add("Niko");
        fotoMakanan.add("https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRHvpYXPMCJ0OFUpdy6YThemXaekNSOQDL-gE_m0HjU74jjydyB&usqp=CAU");
        infoMakanan.add("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's stand Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since t");

        namaMakanan.add("Ryan");
        fotoMakanan.add("https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR6-pZyuUJ2aXGUrnWGyHLgcqhIelQ490ESMSa5lvwz_xhU4l1v&usqp=CAU");
        infoMakanan.add("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's stand Lorem Ipsum iis simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's stand Lorem Ipsum is simply dummy text of the pr");


        prosesRecyclerViewAdapter();

    }
}
