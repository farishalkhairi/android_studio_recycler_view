package com.example.recycler_peler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    ImageView imageviewfoto;
    TextView judul, infoMakanan1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        imageviewfoto = findViewById(R.id.imageviewfoto);
        judul = findViewById(R.id.judul);
        infoMakanan1 = findViewById(R.id.infoMakanan1);

        getIncomingExtra();

    }

    private void getIncomingExtra(){
        if(getIntent().hasExtra("foto_makanan") && getIntent().hasExtra("nama_makanan") && getIntent().hasExtra("info_makanan")){

            String fotoMakanan = getIntent().getStringExtra("foto_makanan");
            String namaMakanan = getIntent().getStringExtra("nama_makanan");
            String infoMakanan = getIntent().getStringExtra("info_makanan");

            setDataActivity(fotoMakanan, namaMakanan, infoMakanan);

        }
    }

    private void setDataActivity(String fotoMakanan, String namaMakanan, String infoMakanan){


        Glide.with(this).asBitmap().load(fotoMakanan).into(imageviewfoto);

        
        judul.setText(namaMakanan);
        infoMakanan1.setText(infoMakanan);






    }

}
